<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class SpeachController extends Controller
{
    public function speachToText(request $request) {

    }
}
